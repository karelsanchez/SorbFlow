"""Local analytic-predictor coverage campaign. No ODE or external FAST code."""
from __future__ import annotations
import os
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_key]='1'
import argparse
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
from dataclasses import asdict
import hashlib
from importlib.metadata import version
import json
import math
from pathlib import Path
import platform
import sys
import time
import numpy as np
from pyfast.calibration.profile import ProfileParameter, profile_gaussian_known_sigma

OUT=Path(__file__).resolve().parents[1]
ROOT=OUT.parents[1]
PROTO=OUT/'protocol/PROTOCOL.json'
TABLE=OUT/'protocol/SOURCE_SCENARIO_TABLE.json'
SEED=int(hashlib.sha256(b'PYFAST_MAIN_ANALYTIC_COVERAGE_20261120_V1').hexdigest()[:16],16)
TOL=1e-5
COUNTS={'S1':1000,'S2W':1000,'S2':200,'S3_d1':200,'S3_d2':200,'S4a':200,'S4b':200}

def raw(obj):return (json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_bytes(),parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
def atomic(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_bytes(raw(obj));tmp.replace(path)
def immutable(path,obj):
    expected=raw(obj)
    if path.exists():
        if path.read_bytes()!=expected:raise ValueError('Immutable mismatch: '+str(path))
    else:atomic(path,obj)

def result_write(path,record):atomic(path,{'body':record,'sha256':sha(raw(record))})
def result_read(path):
    envelope=read(path)
    if sha(raw(envelope['body']))!=envelope['sha256']:raise ValueError('Result checksum mismatch: '+str(path))
    return envelope['body']

def analytic(K,k,beta,t):
    eq=.01/(1+beta*K)
    return eq+(.01-eq)*np.exp(-k*(1+beta*K)*np.asarray(t))

def sources():
    files=list((ROOT/'PyFAST/src/pyfast').rglob('*.py'))+list((OUT/'code').glob('*.py'))+list((OUT/'tests').glob('*.py'))+[TABLE]
    return {str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(files)}

def freeze():
    if PROTO.exists():raise RuntimeError('Protocol already frozen; refuse overwrite')
    p={'study':'E02 analytic-predictor marginal truth inclusion', 'status':'FROZEN_NEW_SCOPED_PROTOCOL_NOT_V2_G2_APPROVAL',
       'sources':sources(),'versions':{n:version(n) for n in ('numpy','scipy','pint','pyfast-adsorption')},'python':sys.version,'platform':platform.platform(),
       'counts':COUNTS,'seed_root':SEED,'seed_label':'MAIN_ANALYTIC_COVERAGE distinct from prior integration root',
       'seed_rule':'SeedSequence(root, spawn_key=(scenario_index, replicate, experiment_index)); save z and y',
       'predictor':'independent closed-form linear batch, same equation for generating and fitting data; numerical API under test is profile_gaussian_known_sigma, not ODE',
       'starts':'two log-interior diagonal starts at fractions 1/3 and 2/3 of log bounds','max_nfev':100,'max_callback_calls_per_profile':1000,
       'baseline_tolerance':TOL,'tolerance_status':'provisional fixed before generation, not inferred or tuned from observed coverage',
       'confidence':.95,'threshold':'scipy.stats.chi2.ppf(.95,1); nominal diagnostic also at boundaries, no calibrated boundary claims',
       'baseline_rule':'two call baselines must agree within absolute tolerance; common reference minimum; any attained objective below reference-tolerance makes dataset inconclusive',
       'class_rule':'each parameter at exact truth; HIT if profile chi2-commonbaseline <= cutoff, MISS otherwise; numerical failures and incoherent baselines INCONCLUSIVE',
       'denominator':'all planned replicas, including unfinished and inconclusive; lower=HIT/N, upper=(HIT+INCONCLUSIVE)/N',
       'statistics':'Wilson pointwise descriptive intervals for lower/upper indicators; no equivalence, joint coverage, multiplicity-adjusted testing, interval closure or novelty claims',
       'regular_comparison':['S1','S2W'],'diagnostics':['S2','S3_d1','S3_d2','S4a','S4b'],
       'design_precision':'M1000 gives approximate 1.96*sqrt(.95*.05/1000)=.01351 nominal design halfwidth; M200=.03021; not guarantee',
       'budget':{'workers':2,'wall_s':7200,'dataset_callback_reservation':2000,'max_total_callbacks':6000000,'physical_ode_solves':0},
       'resume':'terminal results verified against immutable data; started-without-result becomes INTERRUPTED, not silently rerun; reservation retained',
       'amendments_to_V2':{'D01':'direct signed analytic callback, no observation clipping','D02':'S2 diagnostic, S2W primary descriptive comparison','D03':'no equivalence','D04':'bound labels descriptive only; no causal attribution','D05':'no pilot, distinct scoped analytic campaign based on measured integration cost','D06':'no threshold calibration','D07':'no ODE tolerance in analytic callback; optimizer constants frozen by sources','D08':'not estimating V2 tau_inc; provisional absolute tolerance explicit','D09':'two starts, max_nfev100, callbacks1000, no finite global optimum certificate','D10':'M1000 regular/M200 diagnostic frozen','D11':'no new source-dependent claims; save realized arrays','D12':'keep t=0','D13':'no interval-closure study','D14':'new technical execution under user authorization; does not approve V2 gates','D15':'not a pilot','D16':'predictor check independent deterministic prelaunch tests; no ODE coverage claim','D17':'exact source hashes frozen'}}
    atomic(PROTO,p);(PROTO.with_suffix('.sha256')).write_text(sha(PROTO.read_bytes())+'\n')
    print('FROZEN',sha(PROTO.read_bytes()),flush=True)

def verify_protocol():
    p=read(PROTO)
    if sha(PROTO.read_bytes())!=PROTO.with_suffix('.sha256').read_text().strip() or p['sources']!=sources():raise RuntimeError('SOURCE_CHANGED')
    return p

def dataset(scenario,table,replicate):
    times=table['time_sets'][scenario['times']]['value_s'];K=scenario['truth']['K_m3_kg'];k=scenario['truth']['k_s_inv'];batches=[]
    for j,mass in enumerate((.002,.004)):
        key=(scenario['scenario_index'],replicate,j)
        z=np.random.default_rng(np.random.SeedSequence(SEED,spawn_key=key)).standard_normal(len(times))
        truth=analytic(K,k,mass/.001,times)
        batches.append({'mass_kg':mass,'beta_kg_m3':mass/.001,'time_s':times,'truth':truth.tolist(),'z':z.tolist(),'y':(truth+1e-4*z).tolist(),'spawn_key':key})
    return {'scenario':scenario['id'],'replicate':replicate,'seed':SEED,'sigma_kg_m3':1e-4,'truth_parameters':[K,k],'batches':batches}

def classify(profiles):
    if any(p.get('status')!='COMPLETE' or p.get('baseline_inconsistent') for p in profiles):
        return ['INCONCLUSIVE']*2,{'reason':'one or both profile calls incomplete or inconsistent'}
    bases=[p.get('baseline_chi2') for p in profiles]
    if any(v is None or not math.isfinite(v) for v in bases):return ['INCONCLUSIVE']*2,{'reason':'missing baseline'}
    ref=min(bases)
    lows=[t['lowest_evaluated_chi2'] for p in profiles for t in p['baseline_trials']+p['points'][0]['trials'] if t.get('lowest_evaluated_chi2') is not None]
    if max(bases)-min(bases)>TOL or any(v<ref-TOL for v in lows):return ['INCONCLUSIVE']*2,{'reason':'inconsistent baseline','reference':ref}
    classes=[];deltas=[]
    for p in profiles:
        point=p['points'][0];chi=point.get('chi2')
        if p['status']!='COMPLETE' or p['baseline_inconsistent'] or chi is None:
            classes.append('INCONCLUSIVE');deltas.append(None)
        else:
            delta=chi-ref;classes.append('HIT' if delta<=p['cutoff'] else 'MISS');deltas.append(delta)
    return classes,{'reference':ref,'baseline_difference':abs(bases[0]-bases[1]),'delta_chi2':deltas}

def fit_one(task):
    sid,replicate,deadline,remaining=task
    table=read(TABLE);scenario=next(s for s in table['scenarios'] if s['id']==sid)
    path=OUT/'datasets'/sid/f'{replicate:05d}.json';data=read(path);bounds=table['bounds_sets'][scenario['bounds']]
    specs=[ProfileParameter('K','m^3/kg',*bounds['K_m3_kg']),ProfileParameter('k','1/s',*bounds['k_s_inv'])]
    lo,hi=np.log([s.lower for s in specs]),np.log([s.upper for s in specs]);starts=np.exp([lo+(hi-lo)/3,lo+2*(hi-lo)/3]);profiles=[]
    started=time.perf_counter()
    def residual(theta):
        if time.time()>deadline:raise TimeoutError('Campaign wall limit')
        return np.concatenate([(analytic(theta[0],theta[1],b['beta_kg_m3'],b['time_s'])-b['y'])/1e-4 for b in data['batches']])
    for j,spec in enumerate(specs):
        p=profile_gaussian_known_sigma(residual,specs,starts,parameter=spec.name,grid=[data['truth_parameters'][j]],max_callback_calls=1000,max_nfev=100,baseline_tolerance=TOL)
        profiles.append(asdict(p))
    classes,diagnostic=classify(profiles)
    record={'scenario':sid,'replicate':replicate,'data_sha256':sha(path.read_bytes()),'status':'FINALIZED','classifications':dict(zip(('K','k'),classes)),'diagnostic':diagnostic,'profiles':profiles,'callback_calls':sum(p['callback_calls'] for p in profiles),'elapsed_s':time.perf_counter()-started,'physical_ode_solves':0}
    result_write(OUT/'results'/sid/f'{replicate:05d}.json',record)
    return {'scenario':sid,'replicate':replicate,'status':'FINALIZED'}

def wilson(h,n):
    if n<=0:return None
    z=1.959963984540054;p=h/n;d=1+z*z/n;c=(p+z*z/(2*n))/d;w=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [0. if h==0 else max(0,c-w),1. if h==n else min(1,c+w)]

def summarize(final=False):
    rows=[];callbacks=0;count=0
    for sid,N in COUNTS.items():
        records=[result_read(p) for p in sorted((OUT/'results'/sid).glob('*.json'))];count+=len(records)
        callbacks+=sum(r.get('callback_calls',0) for r in records)
        for name in ('K','k'):
            h=sum(r['classifications'].get(name)=='HIT' for r in records);m=sum(r['classifications'].get(name)=='MISS' for r in records);inc=N-h-m
            rows.append({'scenario':sid,'parameter':name,'planned_n':N,'completed_records':len(records),'hit':h,'miss':m,'inconclusive_including_unfinished':inc,'lower_hit_over_planned':h/N,'upper_hit_plus_inconclusive_over_planned':(h+inc)/N,'wilson_lower_indicator':wilson(h,N),'wilson_upper_indicator':wilson(h+inc,N)})
    summary={'status':'FINAL' if final else 'RUNNING','records':count,'planned_records':sum(COUNTS.values()),'callbacks_completed_records':callbacks,'physical_ode_solves':0,'rows':rows,'scope':'Analytic-predictor profile inference only; not column/ODE uncertainty validation','equivalence_claim':False,'joint_coverage_claim':False}
    atomic(OUT/'SUMMARY.json',summary)
    lines=['# E02 — cobertura marginal con predictor analítico','',f"Estado: {summary['status']}; datasets terminales: {count}/{sum(COUNTS.values())}.",'','El predictor es la solución cerrada de batch lineal. Se ejercita la API de perfiles de PyFAST, sin integrar ODE. No se afirma cobertura de columna, incertidumbre experimental, equivalencia ni cobertura conjunta. Los escenarios de frontera usan el umbral nominal solo como diagnóstico.','', '| Escenario | Parámetro | N | HIT | MISS | Inconclusos/no terminados | Cota inferior | Cota superior |','|---|---|---:|---:|---:|---:|---:|---:|']
    lines += [f"| {r['scenario']} | {r['parameter']} | {r['planned_n']} | {r['hit']} | {r['miss']} | {r['inconclusive_including_unfinished']} | {r['lower_hit_over_planned']:.4f} | {r['upper_hit_plus_inconclusive_over_planned']:.4f} |" for r in rows]
    lines += ['','Las cotas anteriores incluyen todos los datasets planeados. Un dato negativo se conserva, sin recortar ni remuestrear. Los registros contienen ambos perfiles completos, intentos y ruido. Las tolerancias son provisionales preespecificadas, no ajustadas después de ver cobertura.','',f'Callbacks de registros completados: {callbacks}. Solves físicos ODE: 0.','', 'La campaña es un protocolo nuevo acotado, no una aprobación retroactiva de las puertas G0–G2 del borrador V2. La reanudación conserva interrupciones; no promete reproducir el estado interno del optimizador.']
    (OUT/'INFORME.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    if final:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(12,5));xs=np.arange(len(rows));lower=[r['lower_hit_over_planned'] for r in rows];upper=[r['upper_hit_plus_inconclusive_over_planned'] for r in rows]
        ax.vlines(xs,lower,upper,color='tab:blue');ax.scatter(xs,lower,label='HIT/N');ax.scatter(xs,upper,marker='x',label='(HIT+inconclusive)/N');ax.axhline(.95,color='black',ls='--',label='nominal .95');ax.set_xticks(xs,[r['scenario']+' '+r['parameter'] for r in rows],rotation=45,ha='right');ax.set_ylim(0,1.03);ax.set_ylabel('Marginal truth-inclusion proportions');ax.legend();fig.tight_layout();fig.savefig(OUT/'coverage.png',dpi=160);plt.close(fig)
    return summary

def terminal_interruption(sid,rep,reason):
    d=OUT/'datasets'/sid/f'{rep:05d}.json'
    result_write(OUT/'results'/sid/f'{rep:05d}.json',{'scenario':sid,'replicate':rep,'status':'INTERRUPTED','data_sha256':sha(d.read_bytes()),'classifications':{'K':'INCONCLUSIVE','k':'INCONCLUSIVE'},'callback_calls':0,'callback_reservation_charged':2000,'reason':reason})

def run():
    p=verify_protocol();atomic(OUT/'PROCESS.json',{'pid':os.getpid(),'protocol_sha256':sha(PROTO.read_bytes())})
    statepath=OUT/'logs/budget.json';budget=read(statepath) if statepath.exists() else {'first_start_epoch_s':time.time(),'wall_used_s':0,'reserved_callbacks':0,'attempts':0}
    start=time.monotonic();deadline=budget['first_start_epoch_s']+7200
    atomic(statepath,budget)
    table=read(TABLE)
    # Materialize all signed observations before the first profile call.
    for s in table['scenarios']:
        for rep in range(COUNTS[s['id']]):immutable(OUT/'datasets'/s['id']/f'{rep:05d}.json',dataset(s,table,rep))
    pending=[]
    for s in table['scenarios']:
        for rep in range(COUNTS[s['id']]):
            sid=s['id'];result=OUT/'results'/sid/f'{rep:05d}.json';reservation=OUT/'reservations'/sid/f'{rep:05d}.json'
            if result.exists():
                old=result_read(result)
                if old['data_sha256']!=sha((OUT/'datasets'/sid/f'{rep:05d}.json').read_bytes()):raise ValueError('Result/data mismatch')
            elif reservation.exists():terminal_interruption(sid,rep,'Reserved before previous coordinator stopped; no silent rerun')
            else:pending.append((sid,rep))
    # Reconcile an interruption between durable reservation and budget snapshot.
    budget['attempts']=len(list((OUT/'reservations').glob('*/*.json')))
    budget['reserved_callbacks']=2000*budget['attempts']
    atomic(statepath,budget)
    with ProcessPoolExecutor(max_workers=2) as pool:
        futures={};cursor=0;last_report=time.monotonic()
        while cursor<len(pending) or futures:
            while cursor<len(pending) and len(futures)<2 and time.time()<deadline:
                sid,rep=pending[cursor];cursor+=1
                if budget['reserved_callbacks']+2000>6000000:raise RuntimeError('Frozen global callback reservation exhausted')
                immutable(OUT/'reservations'/sid/f'{rep:05d}.json',{'callbacks_reserved':2000,'dataset':sid,'replicate':rep})
                budget['reserved_callbacks']+=2000;budget['attempts']+=1;budget['wall_used_s']=time.time()-budget['first_start_epoch_s']
                atomic(statepath,budget);futures[pool.submit(fit_one,(sid,rep,deadline,1000))]=(sid,rep)
            if not futures:break
            done,_=wait(futures,timeout=2,return_when=FIRST_COMPLETED)
            for future in done:
                sid,rep=futures.pop(future)
                try:future.result()
                except Exception as exc:terminal_interruption(sid,rep,f'{type(exc).__name__}: {exc}')
            if time.monotonic()-last_report>30:
                summary=summarize();print('records',summary['records'],flush=True);last_report=time.monotonic()
            if time.time()>deadline and not futures:break
    budget['wall_used_s']=time.time()-budget['first_start_epoch_s'];atomic(statepath,budget)
    verify_protocol();summary=summarize(final=True)
    atomic(OUT/'STATUS.json',{'status':'COMPLETE' if summary['records']==sum(COUNTS.values()) else 'WALL_BUDGET_REACHED','records':summary['records'],'planned':sum(COUNTS.values()),'budget':budget})
    print('Finished',summary['records'],flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=('freeze','run','report'));args=parser.parse_args()
    {'freeze':freeze,'run':run,'report':lambda:summarize(True)}[args.command]()
