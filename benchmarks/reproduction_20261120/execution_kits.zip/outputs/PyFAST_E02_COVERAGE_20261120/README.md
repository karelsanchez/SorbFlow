# E02: inclusión marginal de la verdad con predictor analítico

Esta campaña comprueba la API de perfiles gaussianos con sigma diagonal conocida, utilizando el modelo batch lineal exacto. No comprueba propagación de incertidumbre en una columna, error del solver ODE, intervalos continuos ni validación ambiental.

Es un protocolo nuevo y acotado. El borrador V2 y sus puertas G0–G2 se preservan sin aprobarlos retroactivamente. La tabla fuente se copia íntegra en protocol/SOURCE_SCENARIO_TABLE.json; PROTOCOL.json registra las decisiones específicas nuevas.

- S1 y S2W: 1.000 datasets cada uno. S2, S3_d1, S3_d2, S4a y S4b: 200 cada uno. Total: 3.000 datasets y 6.000 perfiles evaluados exactamente en la verdad.
- Dos procesos y un hilo BLAS por proceso. Presupuesto: 7.200 segundos desde el primer inicio, incluyendo pausas y reanudaciones, y seis millones de callbacks reservados. Los callbacks son evaluaciones analíticas; solves ODE: cero.
- Dos inicios interiores deterministas; max_nfev=100 y hasta 1.000 callbacks por perfil. Tolerancia de inconsistencia absoluta 1e-5, provisional y fijada antes del muestreo.
- Toda observación se guarda con su ruido; negativos conservados sin recorte ni remuestreo. La raíz MAIN_ANALYTIC_COVERAGE es distinta de la del chequeo de integración anterior.
- Los dos baselines deben concordar. Un fallo o inconsistencia en cualquiera de las llamadas hace inconcluso el dataset para ambos parámetros. Las frecuencias conservan el denominador planeado, también si una campaña queda incompleta.
- No se declara equivalencia, cobertura conjunta, identificabilidad global, corrección de umbrales en frontera ni superioridad.

Desde C:\Users\Karel\Documents\Codex\2026-11-18\empaqueta-x20:

```powershell
# Solo una vez antes del primer dataset:
.\PyFAST\.venv\Scripts\python.exe -I -B outputs\PyFAST_E02_COVERAGE_20261120\code\coverage_run.py freeze
# Ejecutar o reanudar; nunca dos coordinadores simultáneos:
.\PyFAST\.venv\Scripts\python.exe -I -B outputs\PyFAST_E02_COVERAGE_20261120\code\coverage_run.py run
```

Los resultados son envolturas JSON con checksum del contenido; la reanudación verifica los datos y los resultados. Una reserva durable sin resultado se conserva como INTERRUPTED y se cuenta en contra, sin volver a muestrear ni ejecutar silenciosamente el dataset. El estado interno del optimizador no se reanuda.

PROCESS.json registra el PID; background.stdout.log/background.stderr.log conservan los mensajes. SUMMARY.json e INFORME.md se actualizan mientras avanza la campaña. Al finalizar se generan STATUS.json y coverage.png. Cerrar la aplicación no detiene necesariamente el proceso; Windows debe permanecer encendido y sin suspensión.

Antes de congelar: 17 pruebas superadas (incluyen solución ODE independiente del batch lineal y oráculo de media gaussiana). Una ejecución inicial tuvo 15 PASS/1 FAIL: el fallo fue exigir igualdad exacta a cero en un extremo Wilson calculado como 3,47e-18; se corrigió la evaluación de los extremos matemáticos a 0/1 y se repitió la batería. No se habían generado datasets Monte Carlo ni congelado el protocolo en esa corrección.
