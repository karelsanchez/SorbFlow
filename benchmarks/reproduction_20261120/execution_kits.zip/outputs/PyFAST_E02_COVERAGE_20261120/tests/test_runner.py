import importlib.util
import math
from pathlib import Path
import numpy as np
import pytest
from scipy.integrate import solve_ivp

spec=importlib.util.spec_from_file_location('coverage_local',Path(__file__).resolve().parents[1]/'code/coverage_run.py')
R=importlib.util.module_from_spec(spec);spec.loader.exec_module(R)

@pytest.mark.parametrize('K,k,beta',[(.5,.02,2),(.1,.005,4),(2,.08,2)])
def test_independent_linear_ode_oracle(K,k,beta):
    t=np.array([0.,1.,10.,30.,100.,300.])
    def rhs(_,y):
        dq=k*(K*y[0]-y[1]);return [-beta*dq,dq]
    sol=solve_ivp(rhs,(0,300),[.01,0],t_eval=t,rtol=1e-11,atol=1e-14)
    assert sol.success
    assert np.max(abs(sol.y[0]-R.analytic(K,k,beta,t)))<2e-12
    assert np.max(abs(sol.y[0]+beta*sol.y[1]-.01))<1e-12

def sample(status='COMPLETE',baseline=2.,chi=3.,low=2.):
    return {'status':status,'baseline_inconsistent':False,'baseline_chi2':baseline,'cutoff':3.841458820694124,
            'baseline_trials':[{'lowest_evaluated_chi2':low}], 'points':[{'chi2':chi,'trials':[{'lowest_evaluated_chi2':chi}]}]}

def test_common_baseline_and_no_clipping():
    cls,d=R.classify([sample(chi=1.999999),sample(chi=6)])
    assert cls==['HIT','MISS'];assert d['delta_chi2'][0]<0

def test_baseline_disagreement():
    assert R.classify([sample(),sample(baseline=2.001)])[0]==['INCONCLUSIVE']*2

def test_failed_attained_value_triggers_inconsistency():
    a=sample();a['baseline_trials'].append({'lowest_evaluated_chi2':0.})
    assert R.classify([a,sample()])[0]==['INCONCLUSIVE']*2

@pytest.mark.parametrize('status',['BASELINE_INCONSISTENT','BUDGET_EXHAUSTED','ERROR','INCOMPLETE'])
def test_one_bad_call_makes_dataset_inconclusive(status):
    assert R.classify([sample(status=status),sample()])[0]==['INCONCLUSIVE']*2

def test_missing_baseline():
    assert R.classify([sample(baseline=None),sample()])[0]==['INCONCLUSIVE']*2

def test_immutable_and_atomic(tmp_path):
    p=tmp_path/'a.json';R.immutable(p,{'x':1});before=p.read_bytes();R.immutable(p,{'x':1});assert p.read_bytes()==before
    with pytest.raises(ValueError):R.immutable(p,{'x':2})
    assert not p.with_suffix('.json.tmp').exists()

def test_wilson_edges():
    lo,hi=R.wilson(0,100);assert lo==0 and 0<hi<.1
    lo,hi=R.wilson(100,100);assert .9<lo<1 and hi==1

def test_known_gaussian_mean_profile_oracle():
    from pyfast.calibration.profile import ProfileParameter,profile_gaussian_known_sigma
    # Positive parameter with exact unbounded MLE=2 and known variance.
    y=np.array([1.8,2.,2.2]);sigma=.1
    p=profile_gaussian_known_sigma(lambda theta:(theta[0]-y)/sigma,[ProfileParameter('a','1',.1,4)],[[1.],[3.]],parameter='a',grid=[2.1],max_callback_calls=1000,max_nfev=100,baseline_tolerance=R.TOL)
    assert p.status=='COMPLETE'
    assert abs(p.baseline_chi2-8)<1e-8
    assert abs(p.points[0].delta_chi2-3)<1e-8

def test_signed_measurement_residual_is_preserved():
    observed=np.array([-.0002,.0001]);prediction=np.array([0.,0.])
    residual=(prediction-observed)/1e-4
    assert residual.tolist()==[2.,-1.]
    assert np.dot(residual,residual)==5.

def test_design_counts_and_reservation_cap():
    assert sum(R.COUNTS.values())==3000
    assert sum(R.COUNTS.values())*2*1000==6000000

def test_result_cache_checksum_rejects_tampering(tmp_path):
    p=tmp_path/'r.json';R.result_write(p,{'x':1});assert R.result_read(p)=={'x':1}
    r=R.read(p);r['body']['x']=2;R.atomic(p,r)
    with pytest.raises(ValueError,match='checksum'):R.result_read(p)
