# E03 — comparación sintética acotada

Esta carpeta es independiente del repositorio y de las entregas históricas. No contiene curvas ambientales ni material FAST. El modelo de columna es propio de PyFAST, con equilibrio lineal y LDF; todas las distribuciones de incertidumbre son supuestos sintéticos, no estimaciones experimentales.

Antes de iniciar se congela protocol/PROTOCOL.json y su SHA256. El protocolo registra fuentes, entorno, semillas, cajas, mallas, objetivos, restricciones, selección y presupuestos. Los tests del runner usan valores inventados de ingeniería, no ejecutan el solver ni consumen el conjunto principal.

La comparación usa dos semillas de NSGA-II por método. Cada corrida tiene un máximo de 120 solves físicos de entrenamiento: el método nominal puede explorar más diseños que el robusto, que resuelve cinco escenarios por diseño. Se informa el consumo real y la caché; no se afirma igualdad exacta de esfuerzo observado ni convergencia del frente. La búsqueda robusta es deliberadamente pequeña (dos generaciones).

Se conserva un representante por corrida, elegido solo con entrenamiento mediante una regla predefinida. Si no aparece ningún frente factible, se conserva un candidato de mínima violación rotulado como tal. Los representantes y el diseño base quedan congelados antes de generar los cuarenta escenarios independientes y comunes de evaluación.

La evaluación resuelve cada escenario con 40 y 80 celdas y compara curvas completas muestreadas y clasificación de factibilidad. El límite de diferencia es 0,005 en C/C0. Un fallo de malla limita la interpretación y no se oculta. Las tasas de violación y los intervalos Wilson son descriptivos; cuarenta escenarios no garantizan riesgo industrial ni equivalen a validación experimental.

Presupuesto: 1.200 solves nuevos, una ejecución física simultánea y 7.200 segundos de reloj desde el primer inicio (conservador tras pausas). Los resultados se guardan de forma atómica por petición; cada solve tiene una reserva previa en un journal con checksum. Al reanudar, las reservas antiguas siguen contando y la caché se verifica antes de reutilizarla. No ejecutar dos coordinadores simultáneos.

Desde C:\Users\Karel\Documents\Codex\2026-11-18\empaqueta-x20:

```powershell
.\PyFAST\.venv\Scripts\python.exe -I -B outputs\PyFAST_E03_BENCHMARK_20261120\code\run_e03.py freeze
.\PyFAST\.venv\Scripts\python.exe -I -B outputs\PyFAST_E03_BENCHMARK_20261120\code\run_e03.py run
```

La primera orden se ejecuta una sola vez. Para reanudar se usa únicamente `run`. No modificar código, tests o fuentes mientras corre la campaña.

PROCESS.json contiene el PID del intérprete real. STATUS.json muestra avance, final o bloqueo. background.stdout.log y background.stderr.log conservan el registro del proceso oculto. Al terminar se generan RESULTS.json, INFORME.md y comparison.png automáticamente, sin consultar servicios de modelos de lenguaje. El equipo debe seguir encendido y sin suspensión.

No se publica nada en GitHub, no se cambia la licencia y no se redacta el artículo. Esta entrega no cierra la totalidad del E03 propuesto: faltan, entre otros, estudios más amplios de semillas, presupuestos, convergencia Pareto, discrepancia y costo industrial.
