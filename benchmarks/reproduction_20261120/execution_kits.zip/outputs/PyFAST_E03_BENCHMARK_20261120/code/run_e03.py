"""Scoped synthetic E03 benchmark; no language-model calls during execution."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
import subprocess
import sys
import time
from dataclasses import asdict
from importlib.metadata import version
from pathlib import Path

OUT=Path(__file__).resolve().parents[1]
ROOT=OUT.parents[1]
PROTOCOL=OUT/'protocol/PROTOCOL.json'
MAX_SOLVES=1200
MAX_WALL_S=7200
BOUNDS=([.06,.012],[.18,.025])
BASE=[.1,.016]
HORIZON=1800.
LIMIT=.1
PRESSURE_LIMIT=20000.
SEEDS=[202611201,202611202]
TRAIN_SEEDS=[202611211,202611212]

def digest(b): return hashlib.sha256(b).hexdigest()
def strict(value): raise ValueError('Nonfinite JSON '+value)
def read(p): return json.loads(Path(p).read_text(encoding='utf8'),parse_constant=strict)
def write(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf8');os.replace(tmp,p)
def key(v): return digest(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def sources():
    paths=list((ROOT/'PyFAST/src/pyfast').rglob('*.py'))+list((OUT/'code').glob('*.py'))+list((OUT/'tests').glob('*.py'))
    return {str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in sorted(paths)}
def events():
    p=OUT/'runs/ledger.jsonl'
    if not p.exists():return []
    lines=[]
    for line in p.read_bytes().splitlines():
        e=json.loads(line,parse_constant=strict)
        if key(e['body'])!=e['sha256']:raise RuntimeError('Journal checksum mismatch')
        lines.append(e['body'])
    return lines
def append(v):
    p=OUT/'runs/ledger.jsonl';p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('a',encoding='utf8') as f:
        f.write(json.dumps({'body':v,'sha256':key(v)},sort_keys=True,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
def summary_budget():
    e=events();r=[x for x in e if x['event']=='RESERVE'];c=[x for x in e if x['event']=='CLOSE']
    return {'attempted_solves':len(r),'completed_solves':sum(x['status']=='COMPLETE' for x in c),'failures':sum(x['status']!='COMPLETE' for x in c),'open_or_interrupted_attempts':sorted({x['attempt'] for x in r}-{x['attempt'] for x in c}),'measured_s':sum(x.get('elapsed_s',0) for x in c)}
def selection(records):
    """Training only: feasible minimum normalized objective sum, else minimum violation."""
    feasible=[r for r in records if max(r['constraints'])<=0]
    pool=feasible or records
    return min(pool,key=lambda r:(0 if feasible else max(r['constraints']),r['objectives'][0]/.02+r['objectives'][1]/.5))
def compare_curve(a,b): return max(abs(x-y) for x,y in zip(a,b))
def wilson(k,n,z=1.959963984540054):
    a=k/n;den=1+z*z/n;mid=(a+z*z/(2*n))/den;half=z*math.sqrt(a*(1-a)/n+z*z/(4*n*n))/den
    return [mid-half,mid+half]

def freeze():
    if PROTOCOL.exists():raise RuntimeError('Protocol exists; refuse overwrite')
    p={'experiment':'E03 scoped synthetic linear-equilibrium LDF column design benchmark',
       'not_experimental':True,'not_full_E03':True,
       'hypothesis':'Compare nominal and worst-training-scenario design under declared synthetic parameter/input uncertainty; no superiority assumption',
       'sources':sources(),'python':sys.version,'versions':{n:version(n) for n in ['numpy','scipy','pint','pymoo','pyfast-adsorption']},
       'git':subprocess.check_output(['git','-C',str(ROOT/'PyFAST'),'rev-parse','HEAD'],text=True).strip(),
       'physics':{'equilibrium':'Linear K=0.05*mK m3/kg','kinetics':'LDF k=0.02*mk s^-1','flow_m3_s':'1e-7*mQ','Dax_m2_s':1e-5,'C0_kg_m3':.01,'duration_s':HORIZON,'porosity':.4,'particle_density_kg_m3':1000.,'particle_diameter_m':.0003,'clean_initial_bed':True,'boundary_conditions':'PyFAST column Danckwerts inlet / zero-gradient outlet'},
       'design':{'variables':['length_m','diameter_m'],'bounds':BOUNDS,'baseline':BASE},
       'uncertainty':{'status':'ASSUMED_SYNTHETIC_NOT_CALIBRATED','independent_lognormal_logmean':0.,'log_std_K_k_Q':[.25,.4,.15], 'training_seeds':TRAIN_SEEDS,'train_count_per_seed':5,'independent_evaluation_seed':202611209,'evaluation_count':40,'common_eval_scenarios_across_designs':True},
       'objectives':['dry adsorbent mass kg','nominal hydraulic pumping energy J over horizon'],
       'constraints':{'nominal_or_worst_train_final_c_over_C0_max':LIMIT,'worst_train_pressure_drop_pa_max':PRESSURE_LIMIT},
       'optimization':{'engine':'pyfast.optimize.nsga2 / pymoo.NSGA2','population':12,'deterministic_generations':10,'robust_generations':2,'optimizer_seeds':SEEDS,'assigned_max_unique_physical_solves_per_run':120,'fairness':'Equal maximum physical training-solve budgets; actual cache hits and attempted solves reported. Deterministic explores more designs. No convergence or equal actual effort claimed.'},
       'selection':'One representative from returned training feasible front minimizing mass/0.02 + energy/0.5. If no feasible front, choose recorded candidate with smallest max normalized violation then that score; label infeasible.',
       'numerics':{'search_cells':40,'evaluation_cells':[40,80],'rtol':1e-7,'atol_c':1e-11,'atol_q':1e-12,'atol_mass':1e-12,'history':'streaming','jacobian':'analytic','sample_count':201,'mesh_Cstar_threshold':.005,'mass_scaled_threshold':1e-6,'classification_change':'report unresolved; never erase failure'},
       'evaluation':'Freeze all selected designs before generating evaluation scenarios; no refit. Forty common independent scenarios at both meshes. Report violation rates and descriptive Wilson intervals, no chance-constraint guarantee.',
       'limits':{'new_solves':MAX_SOLVES,'wall_s':MAX_WALL_S,'workers':1,'expected_memory_below_GiB':4},
       'failure_policy':'Failed physics solve retained and stops campaign; budget denial recorded. No feasible optimizer result uses predeclared fallback, no false feasibility.',
       'hypervolume':'Descriptive training-front HV with fixed reference [0.06 kg,2 J], bounds failures explicit. Different constraint definitions mean no standalone superiority inference.',
       'scope':'Two optimizer seeds and tiny robust generations are a scoped benchmark, not Pareto convergence, scaling evidence or validation of real water designs.'}
    write(PROTOCOL,p);(PROTOCOL.with_suffix('.sha256')).write_text(digest(PROTOCOL.read_bytes())+'\n')
    print('FROZEN',digest(PROTOCOL.read_bytes()),flush=True)

class Runner:
    def __init__(self):
        import numpy as np
        self.np=np;self.p=read(PROTOCOL)
        if digest(PROTOCOL.read_bytes())!=PROTOCOL.with_suffix('.sha256').read_text().strip() or sources()!=self.p['sources']:raise RuntimeError('SOURCE_CHANGED')
        self.cache_hits=0;self.training_calls={}
        self.start_path=OUT/'runs/start.json'
        if not self.start_path.exists():write(self.start_path,{'epoch':time.time()})
        self.epoch=read(self.start_path)['epoch']
    def status(self,phase,**extra):write(OUT/'STATUS.json',{'status':phase,'budget':summary_budget(),'cache_hits':self.cache_hits,**extra})
    def scenarios(self,seed,n,name):
        p=OUT/'scenarios'/f'{name}.json'
        draw=self.np.random.default_rng(seed).lognormal(0,[.25,.4,.15],(n,3)).tolist()
        value={'seed':seed,'K_k_Q_multipliers':draw}
        if p.exists() and read(p)!=value:raise RuntimeError('Scenario bytes/content changed')
        if not p.exists():write(p,value)
        return draw
    def solve(self,x,s,cells,phase):
        from pyfast import Bed,Operation,SimulationConfig,Species,Linear,LDF
        from pyfast.simulate import column
        from pyfast.solvers import SolverOptions
        from pyfast.design import hydraulics
        req={'x':list(map(float,x)),'scenario':list(map(float,s)),'cells':cells,'sources':key(self.p['sources']),'physics':self.p['physics'],'numerics':self.p['numerics']}
        h=key(req);path=OUT/'runs/cache'/f'{h}.json';hp=path.with_suffix('.sha256')
        if path.exists():
            if not hp.exists() or digest(path.read_bytes())!=hp.read_text().strip():raise RuntimeError('CACHE_HASH_MISMATCH')
            obj=read(path)
            if obj['request']!=req:raise RuntimeError('CACHE_REQUEST_MISMATCH')
            if not all(math.isfinite(v) for v in obj['cstar']):raise RuntimeError('CACHE_NONFINITE')
            self.cache_hits+=1;return obj
        budget=summary_budget()
        if budget['attempted_solves']>=MAX_SOLVES or time.time()-self.epoch>MAX_WALL_S:raise RuntimeError('BUDGET_EXHAUSTED')
        if phase.startswith('TRAIN'):
            n=sum(e['event']=='RESERVE' and e.get('phase')==phase for e in events())
            if n>=120:raise RuntimeError('TRAINING_SOLVE_BUDGET_EXHAUSTED')
        aid=budget['attempted_solves']+1
        append({'event':'RESERVE','attempt':aid,'key':h,'phase':phase,'epoch':time.time()})
        t=time.perf_counter()
        try:
            bed=Bed(length_m=float(x[0]),diameter_m=float(x[1]),particle_diameter_m=.0003,porosity=.4,particle_density_kg_m3=1000.,material='synthetic-generic')
            op=Operation(flow_m3_s=1e-7*s[2],inlet_concentration_kg_m3=.01,duration_s=HORIZON,axial_dispersion_m2_s=1e-5)
            cfg=SimulationConfig(species=Species(name='synthetic-solute'),bed=bed,operation=op,equilibrium=Linear(distribution_m3_kg=.05*s[0]),kinetics=LDF(rate_s_inv=.02*s[1]))
            result=column(cfg,time_s=self.np.linspace(0,HORIZON,201),options=SolverOptions(axial_cells=cells,rtol=1e-7,atol_concentration_kg_m3=1e-11,atol_loading_kg_kg=1e-12,history='streaming',jacobian='analytic'),code_revision=self.p['git'])
            hyd=hydraulics(bed,flow_m3_s=op.flow_m3_s,fluid_density_kg_m3=997,viscosity_pa_s=.00089,pump_efficiency=.6)
            nominal=hydraulics(bed,flow_m3_s=1e-7,fluid_density_kg_m3=997,viscosity_pa_s=.00089,pump_efficiency=.6)
            diag=asdict(result.diagnostics)
            if diag['max_scaled_mass_residual']>1e-6:raise RuntimeError('MASS_GATE_FAILED')
            obj={'request':req,'cstar':(result.outlet_concentration_kg_m3/.01).tolist(),'diagnostics':diag,'objectives':[nominal.dry_adsorbent_mass_kg,nominal.pump_power_w*HORIZON],'pressure_pa':hyd.pressure_drop_pa,'outlet_mass_kg':float(result.outlet_mass_kg[-1])}
            write(path,obj);hp.write_text(digest(path.read_bytes())+'\n')
            append({'event':'CLOSE','attempt':aid,'key':h,'status':'COMPLETE','elapsed_s':time.perf_counter()-t})
            return obj
        except Exception as exc:
            append({'event':'CLOSE','attempt':aid,'key':h,'status':'ERROR','error':str(exc),'elapsed_s':time.perf_counter()-t});raise
    def optimize(self,method,seed,scenarios):
        from pyfast.optimize import nsga2,Evaluation,OptimizationError
        phase=f'TRAIN_{method}_{seed}';records=[]
        def evaluate(x):
            outputs=[self.solve(x,s,40,phase) for s in scenarios]
            f=outputs[0]['objectives'];g=[max(o['cstar'][-1] for o in outputs)/LIMIT-1,max(o['pressure_pa'] for o in outputs)/PRESSURE_LIMIT-1]
            records.append({'x':list(map(float,x)),'objectives':f,'constraints':g})
            self.status(phase,candidate_count=len(records));write(OUT/'runs'/f'{phase}_trace.json',records)
            return Evaluation(objectives=f,constraints=g)
        try:
            front=nsga2(evaluate,*BOUNDS,variable_units=('m','m'),objective_units=('kg','J'),problem_id=f'E03-scoped-{method}-{seed}',seed=seed,n_constraints=2,population_size=12,generations=10 if method=='deterministic' else 2)
            front_records=[{'x':x.tolist(),'objectives':f.tolist(),'constraints':g.tolist()} for x,f,g in zip(front.decisions_si,front.objectives_si,front.normalized_constraints)]
            value={'status':'FEASIBLE_FRONT_FOUND','front':front_records,'evaluations_reported':front.evaluations,'selected':selection(front_records)}
            try:
                from pymoo.indicators.hv import HV
                ref=self.np.array([.06,2.]);f=front.objectives_si
                value['hypervolume_fixed_reference']=float(HV(ref_point=ref)(f)) if self.np.all(f<ref) else None
                value['hypervolume_reference']=[.06,2.]
            except Exception as exc:value['hypervolume_error']=str(exc)
        except OptimizationError as exc:
            if not records:raise
            value={'status':'NO_FEASIBLE_FRONT','error':str(exc),'front':[],'selected':selection(records),'fallback_is_feasible':max(selection(records)['constraints'])<=0}
        value.update(method=method,seed=seed,callback_count=len(records),assigned_training_solve_cap=120)
        write(OUT/'runs'/f'{phase}_result.json',value)
        print(phase,value['status'],value['selected'],flush=True)
        return value
    def run(self):
        write(OUT/'PROCESS.json',{'pid':os.getpid(),'protocol_sha256':digest(PROTOCOL.read_bytes())})
        self.status('RUNNING')
        training=[self.scenarios(seed,5,f'train_{seed}') for seed in TRAIN_SEEDS]
        runs=[]
        # Baseline is a fixed declared design, never selected from evaluation data.
        baseline=self.solve(BASE,[1.,1.,1.],40,'BASELINE')
        for seed,scenarios in zip(SEEDS,training):
            runs.append(self.optimize('deterministic',seed,[[1.,1.,1.]]))
            runs.append(self.optimize('robust',seed,scenarios))
        selected={'baseline':BASE,**{f"{r['method']}_{r['seed']}":r['selected']['x'] for r in runs}}
        fp=OUT/'protocol/DESIGN_FREEZE.json';fr={'protocol_sha256':digest(PROTOCOL.read_bytes()),'selected_designs':selected,'training_runs':runs}
        if fp.exists() and read(fp)!=fr:raise RuntimeError('Design freeze differs on resume')
        if not fp.exists():write(fp,fr)
        append({'event':'DESIGN_FREEZE','sha256':digest(fp.read_bytes())})
        evaluation=self.scenarios(202611209,40,'independent_evaluation')
        results={}
        for name,x in selected.items():
            rows=[]
            for index,s in enumerate(evaluation):
                coarse=self.solve(x,s,40,'EVALUATION');fine=self.solve(x,s,80,'EVALUATION')
                error=compare_curve(coarse['cstar'],fine['cstar'])
                cv=coarse['cstar'][-1]>LIMIT or coarse['pressure_pa']>PRESSURE_LIMIT
                fv=fine['cstar'][-1]>LIMIT or fine['pressure_pa']>PRESSURE_LIMIT
                rows.append({'scenario':index,'cstar_final_coarse':coarse['cstar'][-1],'cstar_final_fine':fine['cstar'][-1],'violates_coarse':cv,'violates_fine':fv,'max_curve_mesh_difference':error,'mesh_pass':error<=.005,'classification_changed':cv!=fv,'mass_scaled_fine':fine['diagnostics']['max_scaled_mass_residual']})
                write(OUT/'runs'/f'{name}_evaluation.json',rows);self.status('EVALUATION',design=name,scenario=index+1)
            n=sum(z['violates_fine'] for z in rows)
            results[name]={'decision':x,'count':40,'violation_count_fine':n,'violation_fraction_fine':n/40,'wilson_95_descriptive':wilson(n,40),'mesh_failures':sum(not z['mesh_pass'] for z in rows),'classification_changes':sum(z['classification_changed'] for z in rows),'objectives_nominal':self.solve(x,[1.,1.,1.],40,'REPORT')['objectives'],'rows':rows}
        mesh_ok=all(v['mesh_failures']==0 and v['classification_changes']==0 for v in results.values())
        if sources()!=self.p['sources']:raise RuntimeError('SOURCE_CHANGED_DURING_RUN')
        obj={'status':'COMPLETED_SCOPED_SYNTHETIC' if mesh_ok else 'COMPLETED_WITH_NUMERICAL_LIMITATIONS','not_full_E03':True,'experimentally_validated':False,'optimizer_convergence_established':False,'training_runs':runs,'independent_evaluation':results,'budget':summary_budget(),'cache_hits':self.cache_hits,'cache_hit_semantics':'current coordinator invocation; physical ledger is cumulative across resumes','wall_s':time.time()-self.epoch,'sources_unchanged_after_run':True}
        write(OUT/'RESULTS.json',obj);self.report(obj);self.status(obj['status'],report='INFORME.md')
    def report(self,obj):
        lines=['# E03 — benchmark sintético acotado','',f"Estado: {obj['status']}.",'','Se utilizó el solver real de PyFAST (LDF y equilibrio lineal) y NSGA-II. Las distribuciones son supuestas, no inferidas de experimentos. No se demuestra convergencia de Pareto ni superioridad científica con dos semillas y dos generaciones robustas.','', '| Diseño | Masa nominal kg | Energía nominal J | Violaciones / 40 | Fallos de malla | Cambios de factibilidad |','|---|---:|---:|---:|---:|---:|']
        for k,v in obj['independent_evaluation'].items():lines.append(f"| {k} | {v['objectives_nominal'][0]:.6g} | {v['objectives_nominal'][1]:.6g} | {v['violation_count_fine']} | {v['mesh_failures']} | {v['classification_changes']} |")
        lines+=['',f"Intentos de solves: {obj['budget']['attempted_solves']}; fallos: {obj['budget']['failures']}; cache hits: {obj['cache_hits']}; tiempo medido: {obj['budget']['measured_s']:.2f} s.",'','El presupuesto máximo de entrenamiento es igual por corrida (120 solves). El número de diseños explorados difiere y los costes reales y los aciertos de caché se informan; no se afirma igualdad exacta de coste observado. Los tiempos se midieron con otras campañas activas, sin inferencia de escalabilidad.','', 'Las tasas de violación y los intervalos Wilson son descriptivos bajo 40 escenarios simulados comunes e independientes de entrenamiento; no garantizan una probabilidad de incumplimiento industrial. Si falla malla o cambia factibilidad, la comparación de diseño queda numéricamente limitada. Una muestra sin violaciones no significa riesgo cero.','', 'La selección de representantes usó solamente entrenamiento y quedó congelada antes de generar los escenarios de evaluación. Los frentes y posibles fallos de factibilidad se conservan. Este benchmark no cierra todo E03 ni valida el caso experimental.']
        (OUT/'INFORME.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,axes=plt.subplots(1,2,figsize=(11,4))
        for r in obj['training_runs']:
            if r['front']:
                axes[0].scatter([x['objectives'][0] for x in r['front']],[x['objectives'][1] for x in r['front']],label=f"{r['method']} {r['seed']}")
        axes[0].set(xlabel='Dry adsorbent mass [kg]',ylabel='Nominal pumping energy [J]',title='Training fronts — no convergence claim');axes[0].legend(fontsize=6)
        names=list(obj['independent_evaluation']);axes[1].bar(range(len(names)),[obj['independent_evaluation'][x]['violation_fraction_fine'] for x in names]);axes[1].set_xticks(range(len(names)),names,rotation=70,fontsize=6);axes[1].set(ylabel='Violation fraction (40 synthetic scenarios)',ylim=(0,1))
        fig.tight_layout();fig.savefig(OUT/'comparison.png',dpi=160);plt.close(fig)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['freeze','run']);args=parser.parse_args()
    if args.action=='freeze':freeze()
    else:
        runner=None
        try:runner=Runner();runner.run()
        except Exception as exc:
            write(OUT/'STATUS.json',{'status':'STOPPED','error':f'{type(exc).__name__}: {exc}','budget':summary_budget()});raise
