import importlib.util
from pathlib import Path
import pytest

spec=importlib.util.spec_from_file_location('e03',Path(__file__).parents[1]/'code/run_e03.py')
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)

def test_key_changes_model_and_scenario():
    assert M.key({'x':[.1,.02],'s':[1,1,1]})!=M.key({'x':[.1,.02],'s':[1,1,2]})
def test_key_order_invariant():assert M.key({'a':1,'b':2})==M.key({'b':2,'a':1})
def test_nonfinite_rejected():
    with pytest.raises(ValueError):M.key({'n':float('nan')})
def test_feasible_selection():
    records=[{'x':[1,1],'objectives':[.001,.001],'constraints':[.1,-1]}, {'x':[2,2],'objectives':[.02,.5],'constraints':[-.1,-1]}]
    assert M.selection(records)['x']==[2,2]
def test_infeasible_fallback():
    records=[{'x':[1,1],'objectives':[1,1],'constraints':[.2,-1]}, {'x':[2,2],'objectives':[2,2],'constraints':[.1,-1]}]
    assert M.selection(records)['x']==[2,2]
def test_curve_comparison():assert M.compare_curve([0,.1,1],[0,.12,.99])==pytest.approx(.02)
def test_wilson_zero_not_zero_risk():
    lo,hi=M.wilson(0,40);assert lo==pytest.approx(0,abs=1e-15) and 0<hi<.1
def test_design_bounds():
    assert all(a<=x<=b for a,x,b in zip(M.BOUNDS[0],M.BASE,M.BOUNDS[1]))
def test_atomic_strict_json(tmp_path):
    p=tmp_path/'x.json';M.write(p,{'x':1});assert M.read(p)=={'x':1}
def test_journal_integrity(tmp_path,monkeypatch):
    monkeypatch.setattr(M,'OUT',tmp_path);M.append({'event':'RESERVE','attempt':1});assert len(M.events())==1
    p=tmp_path/'runs/ledger.jsonl';p.write_text(p.read_text().replace('RESERVE','CHANGED'))
    with pytest.raises(RuntimeError):M.events()
