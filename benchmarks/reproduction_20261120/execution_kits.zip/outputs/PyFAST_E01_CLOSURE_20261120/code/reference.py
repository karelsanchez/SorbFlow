"""Independent mathematical references; never import PyFAST operators."""
import math
import numpy as np
from scipy.optimize import brentq
from scipy.linalg import expm

def langmuir_batch(times,c0,q0,ratio,qmax,b,k):
    total=c0+ratio*q0
    bb=1-b*total+ratio*qmax*b
    root=math.sqrt(bb*bb+4*b*total)
    cp=2*total/(bb+root) if bb>=0 else (-bb+root)/(2*b)
    cn=(-bb-root)/(2*b)
    alpha=(1+b*cp)/(b*(cp-cn)); beta=(1+b*cn)/(b*(cn-cp))
    if c0==cp: c=np.full(len(times),cp)
    else:
        def implicit(c,t):
            return alpha*math.log(abs((c-cp)/(c0-cp)))+beta*math.log(abs((c-cn)/(c0-cn)))+k*t
        near=np.nextafter(cp,c0)
        def value(t):
            if t==0:return c0
            if implicit(near,t)>0:return cp
            lo,hi=sorted([c0,near])
            return brentq(lambda c:implicit(c,t),lo,hi,xtol=1e-17,rtol=1e-14)
        c=np.array([value(float(t)) for t in times])
    return c,(total-c)/ratio

def hsdm_linear_matrix(cfg,n,nr):
    """Own shell-volume balance and analytic series film/surface resistance.

    Matrix verifies the discrete coupled problem, not a continuous PDE reference.
    """
    bed,op,kin=cfg['bed'],cfg['operation'],cfg['kinetics']
    L,d,eps,rho=bed['length_m'],bed['diameter_m'],bed['porosity'],bed['particle_density_kg_m3']
    R=bed['particle_diameter_m']/2; dr=R/nr; dz=L/n
    area=math.pi*d*d/4; u=op['flow_m3_s']/area; D=op['axial_dispersion_m2_s']
    K=cfg['equilibrium']['distribution_m3_kg']; Ds=kin['surface_diffusivity_m2_s']; kf=kin['film_coefficient_m_s']
    edges=np.arange(nr+1)*dr; volumes=(edges[1:]**3-edges[:-1]**3)/3
    weights=volumes/volumes.sum()
    g=1/(1/kf+(dr/2)/(rho*Ds*K))
    def f(y,feed):
        c=y[:n];q=y[n:].reshape(n,nr)
        dq=np.zeros_like(q); dc=np.zeros(n)
        for i in range(n):
            incoming=u*feed if i==0 else u*c[i-1]-eps*D*(c[i]-c[i-1])/dz
            outgoing=u*c[i] if i==n-1 else u*c[i]-eps*D*(c[i+1]-c[i])/dz
            j=g*(c[i]-q[i,-1]/K)
            dc[i]=(incoming-outgoing)/(eps*dz)-3*(1-eps)*j/(eps*R)
            dq[i,-1]+=R*R*j/(rho*volumes[-1])
            for jface in range(1,nr):
                flux=edges[jface]**2*Ds*(q[i,jface]-q[i,jface-1])/dr
                dq[i,jface-1]+=flux/volumes[jface-1]
                dq[i,jface]-=flux/volumes[jface]
        return np.concatenate([dc,dq.ravel()])
    size=n*(nr+1); zero=np.zeros(size)
    M=np.column_stack([f(np.eye(size)[i],0) for i in range(size)])
    force=f(zero,op['inlet_concentration_kg_m3'])
    aug=np.zeros((size+1,size+1));aug[:size,:size]=M;aug[:size,-1]=force
    y0=np.r_[np.full(n,op['initial_concentration_kg_m3']),np.full(n*nr,op['initial_loading_kg_kg']),1.]
    mass_weights=np.r_[np.full(n,eps*area*dz),np.tile((1-eps)*rho*area*dz*weights,n)]
    return aug,y0,weights,mass_weights

def hsdm_reference(cfg,n,nr,times):
    M,y0,weights,mw=hsdm_linear_matrix(cfg,n,nr)
    states=np.stack([(expm(M*float(t))@y0)[:-1] for t in times])
    return states[:,:n],np.einsum('tir,r->ti',states[:,n:].reshape(len(times),n,nr),weights),states[:,n:].reshape(len(times),n,nr)
