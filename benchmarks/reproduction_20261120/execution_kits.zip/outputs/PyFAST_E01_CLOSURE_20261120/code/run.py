"""Prospectively frozen scoped E01 supplement; one local solver worker at a time."""
from __future__ import annotations
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import hashlib,json,math,sys,time,subprocess,traceback
from importlib.metadata import version
from pathlib import Path
from dataclasses import asdict
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from reference import langmuir_batch,hsdm_linear_matrix,hsdm_reference

OUT=Path(__file__).resolve().parents[1];ROOT=OUT.parents[1];PROTO=OUT/'protocol/PROTOCOL.json'
def read(p):return json.loads(p.read_text(encoding='utf8'),parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf8');tmp.replace(p)
def sources():
    paths=list((ROOT/'PyFAST/src/pyfast').rglob('*.py'))+list((OUT/'code').glob('*.py'))
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
def base(kin='ldf',linear=False):
    area=math.pi*.01**2/4
    return {'schema_version':1,'species':{'name':'synthetic-solute','molar_mass_kg_mol':None},
      'bed':{'length_m':.05,'diameter_m':.01,'particle_diameter_m':.0002,'porosity':.4,'particle_density_kg_m3':1000.,'material':'generic-synthetic','mass_basis':'dry'},
      'operation':{'flow_m3_s':area*.0002,'inlet_concentration_kg_m3':.01,'duration_s':30000.,'axial_dispersion_m2_s':1.25e-5,'initial_concentration_kg_m3':0.,'initial_loading_kg_kg':0.,'temperature_k':298.15},
      'equilibrium':{'kind':'linear','distribution_m3_kg':.1} if linear else {'kind':'langmuir','qmax_kg_kg':.001,'affinity_m3_kg':100.},
      'kinetics':{'kind':'ldf','rate_s_inv':.003} if kin=='ldf' else {'kind':'hsdm','surface_diffusivity_m2_s':1e-12,'film_coefficient_m_s':1e-6}}
def batch_config(c0,q0):
    return {'schema_version':1,'species':{'name':'synthetic-solute','molar_mass_kg_mol':None},'material':'generic-synthetic', 'liquid_volume_m3':.001,'adsorbent_mass_kg':.002,'duration_s':3000.,'initial_concentration_kg_m3':c0,'initial_loading_kg_kg':q0,'equilibrium':{'kind':'langmuir','qmax_kg_kg':.015,'affinity_m3_kg':200.},'kinetics':{'kind':'ldf','rate_s_inv':.003},'temperature_k':298.15}
def jobs():
    js=[]
    def add(name,family,cfg,n=10,nr=8,method='BDF',rtol=1e-9):js.append({'id':name,'family':family,'config':cfg,'n':n,'nr':nr,'method':method,'rtol':rtol})
    for label,c0,q0 in [('adsorption',.01,0.),('desorption',.001,.01)]:
      for method in ['BDF','Radau']:
       for tol in [1e-6,1e-9]:add(f'batch_{label}_{method}_{tol}','batch',batch_config(c0,q0),method=method,rtol=tol)
    for n in [100,200,400,800]:
      for method in ['BDF','Radau']:add(f'ldf_{n}_{method}','ldf',base(),n=n,method=method)
    for tol in [1e-4,1e-6]:add(f'ldf_tol_{tol}','ldf_temporal',base(),n=400,rtol=tol)
    for kf in [1e-7,1e-5]:
      for method in ['BDF','Radau']:
       cfg=base('hsdm',True);cfg['kinetics'].update(surface_diffusivity_m2_s=1e-10,film_coefficient_m_s=kf);cfg['operation'].update(initial_concentration_kg_m3=.002,initial_loading_kg_kg=.00005)
       add(f'hsdm_matrix_{kf}_{method}','hsdm_matrix',cfg,n=3,nr=4,method=method)
    for nr in [6,12,24]:add(f'hsdm_radial_{nr}','hsdm_radial',base('hsdm',True),n=20,nr=nr)
    for n,nr,method in [(10,8,'BDF'),(10,8,'Radau'),(20,8,'BDF'),(10,16,'BDF')]:add(f'hsdm_nonlinear_{n}_{nr}_{method}','hsdm_nonlinear',base('hsdm'),n=n,nr=nr,method=method)
    return js

def reference_tests():
    checks={}
    for label,c0,q0 in [('ads',.01,0.),('des',.001,.01)]:
      t=np.array([0.,1.,10.,100.,300.,1000.,3000.]);c,q=langmuir_batch(t,c0,q0,2,.015,200,.003)
      checks[label+'_initial']=abs(c[0]-c0)<1e-15 and abs(q[0]-q0)<1e-15
      checks[label+'_mass']=np.max(abs(c+2*q-(c0+2*q0)))<1e-15
      h=.001;tt=np.array([1.,10.,100.,300.]);cp,_=langmuir_batch(tt+h,c0,q0,2,.015,200,.003);cm,_=langmuir_batch(tt-h,c0,q0,2,.015,200,.003);ct,qt=langmuir_batch(tt,c0,q0,2,.015,200,.003)
      expect=-2*.003*(.015*200*ct/(1+200*ct)-qt)
      checks[label+'_derivative']=float(np.max(abs((cp-cm)/(2*h)-expect)))<1e-11
    cfg=base('hsdm',True);cfg['kinetics']['surface_diffusivity_m2_s']=1e-10
    M,y0,w,mass=hsdm_linear_matrix(cfg,3,4); row=mass@M[:-1,:-1];expected=np.zeros_like(row);expected[2]=-cfg['operation']['flow_m3_s']
    checks['matrix_mass_row']=np.max(abs(row-expected))<1e-16
    checks['matrix_mass_feed']=abs(mass@M[:-1,-1]-cfg['operation']['flow_m3_s']*.01)<1e-18
    checks['radial_weights']=abs(w.sum()-1)<1e-15
    write(OUT/'REFERENCE_TESTS.json',{'checks':{k:bool(v) for k,v in checks.items()},'passed':all(checks.values()),'physical_solves':0})
    if not all(checks.values()):raise RuntimeError(str(checks))
    return checks

def freeze():
    if PROTO.exists():raise RuntimeError('Protocol already frozen')
    reference_tests()
    value={'id':'E01 scoped supplement 20261120','sources':sources(),'jobs':jobs(),'job_count':len(jobs()),
      'environment':{'python':sys.version,'versions':{name:version(name) for name in ['numpy','scipy','pyfast-adsorption']},'git_head':subprocess.run(['git','-C',str(ROOT/'PyFAST'),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()},
      'budget':{'max_solves':100,'global_wall_s':3600,'per_solve_wall_s':180,'parallel_workers':1},
      'times':'batch201; matrix61; othercolumns4001 equally spaced including endpoints',
      'criteria':{'batch_error_scaled_loose':1e-4,'batch_error_scaled_strict':1e-6,'hsdm_matrix_scaled_error':1e-6,'column_method_cstar':1e-5,'final_mesh_relative_indicators':.005,'hsdm_radial_final_cstar':.005,'hsdm_nonlinear_method_cstar':1e-5,'mass_absolute_kg':1e-12,'mass_scaled':1e-6,'negative_tolerance_atol_multiple':10},
      'indicators':'first upward crossings t10,t50,t90 linearly interpolated; solid mass at t50 via dry-solid loading integral (not total removal)',
      'scope':'Synthetic single species fixed-temperature cases. Own implicit nonlinear batch reference and own coupled linear HSDM FV matrix; matrix reference verifies a discrete problem only. Cross-method/refinement cases are not analytic references.',
      'prior_knowledge':'E01A/B and selected C-A/C-B refinements known; not blind. No previous production solve run to choose these job parameters or thresholds.',
      'failures':'Keep every failed/timed out job. Missing crossing INCONCLUSIVE; failed criteria FAILED; no adaptive mesh or threshold changes. Resume completed outputs only after exact source/protocol/request/array hash check.',
      'excluded':['continuous nonlinear manufactured solution','full Pe/Da/Bi stiffness map','instantaneous-equilibrium reduced PDE','multicomponent/thermal/time-varying inputs','experimental validation','FAST concordance','nonlinear HSDM analytic reference and full spatial convergence']}
    write(PROTO,value);(PROTO.with_suffix('.sha256')).write_text(sha(PROTO)+'\n');print(sha(PROTO),flush=True)

def worker(jobpath):
    from pyfast import SimulationConfig,BatchConfig
    from pyfast.simulate import batch,column
    from pyfast.solvers import SolverOptions
    job=read(jobpath);isbatch=job['family']=='batch'
    cfg=(BatchConfig if isbatch else SimulationConfig).from_json(json.dumps(job['config']))
    hs=not isbatch and job['config']['kinetics']['kind']=='hsdm'
    settings=SolverOptions(method=job['method'],rtol=job['rtol'],atol_concentration_kg_m3=1e-12,atol_loading_kg_kg=1e-13,atol_mass_kg=1e-14,axial_cells=job['n'],radial_cells=job['nr'],jacobian='finite_difference' if hs or isbatch else 'analytic',history='dense' if hs or isbatch else 'streaming')
    count=201 if isbatch else 61 if job['family']=='hsdm_matrix' else 4001
    duration=cfg.duration_s if isbatch else cfg.operation.duration_s;ts=np.linspace(0,duration,count)
    t=time.perf_counter();res=(batch if isbatch else column)(cfg,time_s=ts,options=settings)
    arrays=jobpath.parent/'arrays.npz';np.savez_compressed(arrays,t=res.time_s,c=res.concentration_kg_m3,q=res.loading_kg_kg,inventory=res.inventory_kg,m_in=res.inlet_mass_kg,m_out=res.outlet_mass_kg)
    write(jobpath.parent/'result.json',{'status':'COMPLETE','solve_s':time.perf_counter()-t,'diagnostics':asdict(res.diagnostics),'request_sha256':sha(jobpath),'arrays_sha256':sha(arrays),'config_sha256':cfg.sha256})

def indicator(a,cfg):
    out=a['c'][:,-1]/cfg['operation']['inlet_concentration_kg_m3']; t=a['t']; ans={}
    for f in [.1,.5,.9]:
      hit=np.flatnonzero(out>=f)
      ans['t'+str(int(f*100))]=None if not len(hit) else float(t[hit[0]]) if hit[0]==0 else float(t[hit[0]-1]+(f-out[hit[0]-1])*(t[hit[0]]-t[hit[0]-1])/(out[hit[0]]-out[hit[0]-1]))
    v=math.pi*cfg['bed']['diameter_m']**2/4*cfg['bed']['length_m'];rhob=(1-cfg['bed']['porosity'])*cfg['bed']['particle_density_kg_m3']
    ans['solid_mass_at_t50_kg']=None if ans['t50'] is None else float(np.interp(ans['t50'],t,v*rhob*a['q'].mean(axis=1)))
    return ans

def aggregate(protocol,records,sources_unchanged=True):
    crit=protocol['criteria']; checks=[];metrics={};data={}
    def check(name,value,limit):checks.append({'name':name,'value':float(value),'limit':limit,'pass':bool(math.isfinite(value) and value<=limit)})
    for job in protocol['jobs']:
      name=job['id']; rec=records[name]
      if rec['status']!='COMPLETE':continue
      a=dict(np.load(OUT/'runs'/name/'arrays.npz'));data[name]=a;d=rec['diagnostics']
      check(name+'_mass_abs',d['max_abs_mass_residual_kg'],crit['mass_absolute_kg']);check(name+'_mass_scaled',d['max_scaled_mass_residual'],crit['mass_scaled'])
      check(name+'_negative_c',max(0.,-d['min_concentration_kg_m3']),1e-11);check(name+'_negative_q',max(0.,-d['min_loading_kg_kg']),1e-12)
      cfg=job['config'];family=job['family']
      if family=='batch':
        c,q=langmuir_batch(a['t'],cfg['initial_concentration_kg_m3'],cfg['initial_loading_kg_kg'],2,.015,200,.003)
        err=max(float(np.max(abs(a['c'][:,0]-c))/.01),float(np.max(abs(a['q'][:,0]-q))/.015))
        check(name+'_independent_reference',err,crit['batch_error_scaled_strict'] if job['rtol']==1e-9 else crit['batch_error_scaled_loose'])
      elif family=='hsdm_matrix':
        c,q,rad=hsdm_reference(cfg,job['n'],job['nr'],a['t'])
        check(name+'_independent_matrix_c',np.max(abs(a['c']-c))/.01,crit['hsdm_matrix_scaled_error']);check(name+'_independent_matrix_q',np.max(abs(a['q']-q))/.001,crit['hsdm_matrix_scaled_error'])
      else:metrics[name]=indicator(a,cfg)
    for n in [100,200,400,800]:
      aa=data.get(f'ldf_{n}_BDF');bb=data.get(f'ldf_{n}_Radau')
      if aa is not None and bb is not None:check(f'ldf_{n}_method',np.max(abs(aa['c'][:,-1]-bb['c'][:,-1]))/.01,crit['column_method_cstar'])
    convergence={};inconclusive=[]
    for method in ['BDF','Radau']:
      for key in ['t10','t50','t90','solid_mass_at_t50_kg']:
       coarse=metrics.get(f'ldf_400_{method}',{}).get(key);fine=metrics.get(f'ldf_800_{method}',{}).get(key)
       if coarse is None or fine is None or fine==0:inconclusive.append(f'{method}:{key}:missing/censored');continue
       value=abs(fine-coarse)/abs(fine);check(f'ldf_final_refinement_{method}_{key}',value,crit['final_mesh_relative_indicators'])
       convergence[f'{method}_{key}']={'coarse':coarse,'fine':fine,'relative_change':value}
    for name in ['ldf_tol_0.0001','ldf_tol_1e-06']:
      if name in data and 'ldf_400_BDF' in data:check(name+'_strict_difference',np.max(abs(data[name]['c'][:,-1]-data['ldf_400_BDF']['c'][:,-1]))/.01,1e-3 if '0.0001' in name else 1e-5)
    if 'hsdm_radial_12' in data and 'hsdm_radial_24' in data:check('hsdm_radial_final_outlet',np.max(abs(data['hsdm_radial_12']['c'][:,-1]-data['hsdm_radial_24']['c'][:,-1]))/.01,crit['hsdm_radial_final_cstar'])
    if 'hsdm_nonlinear_10_8_BDF' in data and 'hsdm_nonlinear_10_8_Radau' in data:check('hsdm_nonlinear_methods',np.max(abs(data['hsdm_nonlinear_10_8_BDF']['c']-data['hsdm_nonlinear_10_8_Radau']['c']))/.01,crit['hsdm_nonlinear_method_cstar'])
    failures=[c for c in checks if not c['pass']];invalid=[k for k,v in records.items() if v['status']!='COMPLETE']
    summary={'status':'STOPPED_SOURCE_CHANGED' if not sources_unchanged else 'FAILED_SCOPED_SUPPLEMENT' if failures or invalid else 'INCONCLUSIVE_SCOPED_SUPPLEMENT' if inconclusive else 'PASSED_SCOPED_SUPPLEMENT','checks':checks,'failed_checks':failures,'invalid_jobs':invalid,'inconclusive_indicators':inconclusive,'indicators':metrics,'convergence':convergence,'solve_count':len(records),'e01_general_closed':False,'experimental_validation':False,'excluded':protocol['excluded']}
    write(OUT/'RESULTS.json',summary)
    try:
      import matplotlib;matplotlib.use('Agg')
      import matplotlib.pyplot as plt
      fig,ax=plt.subplots(figsize=(8,5))
      for n in [100,200,400,800]:
       if f'ldf_{n}_BDF' in data:
        a=data[f'ldf_{n}_BDF'];ax.plot(a['t'],a['c'][:,-1]/.01,label=f'N={n}')
      ax.set(xlabel='Time [s]',ylabel='C/C0',title='Synthetic nonlinear LDF axial refinement');ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(OUT/'ldf_refinement.png',dpi=160);plt.close(fig)
    except Exception as e:write(OUT/'PLOT_ERROR.json',{'error':str(e)})
    lines=['# E01: suplemento acotado de verificación','',f"Estado: {summary['status']}. Casos: {len(records)}; criterios evaluados: {len(checks)}; fallidos: {len(failures)}.",'','No cierra E01 general ni constituye validación experimental. No usa FAST ni datos experimentales.','', 'La referencia batch no lineal se deriva por eliminación de masa y separación analítica, evaluada mediante raíces escalares. La matriz HSDM se construye con balances propios de cascarones y eliminación analítica de la película lineal; verifica el sistema discreto, no la EDP continua.','', 'Las comparaciones BDF/Radau y refinamientos son verificaciones de consistencia, no referencias analíticas. La capacidad informada es masa sólida por integración de q y densidad seca; no se confunde con remoción líquida total.','', '## Fallos e inconclusos','']
    lines += [f"- {c['name']}: {c['value']:.6g} > {c['limit']:.6g}" for c in failures]+[f'- {x}' for x in invalid+inconclusive]
    lines += ['', '## Brechas conservadas','']+[f'- {x}' for x in protocol['excluded']]
    (OUT/'INFORME.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    write(OUT/'GAP_MATRIX.json',{'covered_in_this_scope':['nonlinear Langmuir batch closed mass reference','coupled linear HSDM discrete matrix with finite film','nonlinear LDF axial/method/tolerance refinement','coupled HSDM radial and nonlinear method comparisons'],'not_closed':protocol['excluded'],'acceptance_status':summary['status']})
    return summary

def run():
    protocol=read(PROTO)
    if sources()!=protocol['sources'] or sha(PROTO)!=PROTO.with_suffix('.sha256').read_text().strip():raise RuntimeError('SOURCE_CHANGED')
    write(OUT/'PROCESS.json',{'pid':os.getpid(),'protocol_sha256':sha(PROTO)})
    ledger_path=OUT/'LEDGER.json'; ledger=read(ledger_path) if ledger_path.exists() else []
    for entry in ledger:
      if entry['status']=='RESERVED':entry.update(status='INTERRUPTED',charged_s=180.)
    write(ledger_path,ledger)
    records={};start=time.perf_counter();launched=len(ledger)
    for job in protocol['jobs']:
      d=OUT/'runs'/job['id'];rp=d/'request.json';rr=d/'result.json'
      if rr.exists():
        rec=read(rr)
        if rec.get('status')=='COMPLETE' and rec.get('request_sha256')==sha(rp) and read(rp)==job and rec['arrays_sha256']==sha(d/'arrays.npz'):records[job['id']]=rec;continue
        if rec.get('status') in ['ERROR','TIMEOUT'] and read(rp)==job:records[job['id']]=rec;continue
        raise RuntimeError('Invalid durable cache '+job['id'])
      prior=[e for e in ledger if e['job']==job['id']]
      if prior:records[job['id']]={'status':prior[-1]['status'],'note':'Interrupted/failed requests are not silently retried'};continue
      charged=sum(e.get('charged_s',180.) for e in ledger)
      if time.perf_counter()-start>3600 or charged+180>3600 or launched>=100:records[job['id']]={'status':'BUDGET_EXHAUSTED'};continue
      write(rp,job);write(d/'reserved.json',{'max_solve_s':180,'protocol_sha256':sha(PROTO),'request_sha256':sha(rp)});launched+=1
      entry={'job':job['id'],'status':'RESERVED','reserved_s':180,'request_sha256':sha(rp),'protocol_sha256':sha(PROTO)};ledger.append(entry);write(ledger_path,ledger);attempt_start=time.perf_counter()
      try:
        with (d/'stdout.log').open('w') as so,(d/'stderr.log').open('w') as se:
          p=subprocess.Popen([sys.executable,'-I','-B',str(Path(__file__).resolve()),'worker',str(rp)],stdout=so,stderr=se)
          try:p.wait(timeout=min(180,max(1,3600-(time.perf_counter()-start))))
          except subprocess.TimeoutExpired:
            # Only the tree launched for this attempt is terminated.
            subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15)
            p.wait(timeout=15)
            raise
        rec=read(rr) if rr.exists() and p.returncode==0 else {'status':'ERROR','exit_code':p.returncode}
      except subprocess.TimeoutExpired:rec={'status':'TIMEOUT'}
      entry.update(status=rec['status'],charged_s=time.perf_counter()-attempt_start);write(ledger_path,ledger)
      if rec['status']!='COMPLETE':write(rr,rec)
      records[job['id']]=rec
      write(OUT/'STATUS.json',{'status':'RUNNING','completed_or_failed':len(records),'total':len(protocol['jobs']),'latest':job['id'],'latest_status':rec['status'],'wall_s':time.perf_counter()-start})
      print(job['id'],rec['status'],flush=True)
    summary=aggregate(protocol,records,sources()==protocol['sources'])
    summary['sources_unchanged_after']=sources()==protocol['sources'];summary['wall_s']=time.perf_counter()-start;write(OUT/'RESULTS.json',summary)
    write(OUT/'STATUS.json',{'status':summary['status'],'completed_or_failed':len(records),'total':len(protocol['jobs']),'wall_s':summary['wall_s'],'report':'INFORME.md'})
    write(OUT/'MANIFEST.json',{'protocol_sha256':sha(PROTO),'sources_after':sources(),'files':{str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and p.suffix not in ['.log']}})

if __name__=='__main__':
    try:
      if sys.argv[1]=='freeze':freeze()
      elif sys.argv[1]=='test':reference_tests()
      elif sys.argv[1]=='worker':worker(Path(sys.argv[2]))
      elif sys.argv[1]=='run':run()
    except Exception as e:
      if len(sys.argv)>1 and sys.argv[1]=='run':write(OUT/'STATUS.json',{'status':'STOPPED','error':str(e),'traceback':traceback.format_exc()})
      raise
