# E01 — suplemento numérico acotado

Campaña sintética independiente de las entregas E01-A/B anteriores. No altera PyFAST ni datos experimentales.

- Protocolo SHA256: `5c3630b7cd27689dff0a48c3eab501acd967fbcd348b6c6ab924a653d840210d`.
- Se congelaron 29 configuraciones antes de ejecutar el primer solve.
- Referencias: Langmuir batch por separación analítica y eliminación de masa; HSDM lineal acoplado con película mediante matriz propia de volúmenes finitos y exponencial matricial.
- Nueve comprobaciones algebraicas y validación de los esquemas públicos se ejecutaron antes de congelar, sin solves de PyFAST.
- Otros casos: columna Langmuir-LDF con refinamientos axiales/temporales y BDF/Radau; HSDM lineal con refinamiento radial; HSDM Langmuir con comparación entre métodos y mallas descriptivas.

La matriz de HSDM verifica un sistema discreto, no una solución continua. Acuerdo entre métodos, refinamiento y cierre de masa son evidencias distintas. La masa sólida se calcula a partir de carga y densidad seca; no se iguala a toda la remoción líquida.

Se usa un único worker local. Límites: 100 solves, 3.600 segundos acumulados reservados/cargados y de reloj por invocación, 180 segundos por solve. El registro LEDGER.json conserva reservas y consume conservadoramente 180 segundos si una ejecución se interrumpe sin cierre. No se reintentan silenciosamente los fallos. Un timeout termina únicamente el árbol de procesos lanzado por esta campaña.

PROCESS.json identifica el coordinador real; STATUS.json y background.stdout.log registran avance. Al finalizar se generan INFORME.md, RESULTS.json, GAP_MATRIX.json, MANIFEST.json y una figura de refinamiento. Los fallos e indicadores censurados permanecen registrados. Una fuente alterada impide clasificar el suplemento como aprobado.

Reanudar solo cuando no haya otro coordinador activo, desde la carpeta del proyecto:

```powershell
.\PyFAST\.venv\Scripts\python.exe -I -B outputs\PyFAST_E01_CLOSURE_20261120\code\run.py run
```

La verificación del software usa referencias y datos sintéticos; no exige un ensayo nuevo de laboratorio. Tampoco equivale a validación experimental. E01 general conserva brechas explícitas: MMS continua no lineal, límites reducidos de equilibrio instantáneo, mapa general de rigidez/Pe/Da/Bi, convergencia espacial completa HSDM no lineal y condiciones multicomponente, térmicas o variables. No se usa ni redistribuye FAST.

Los cálculos no consultan modelos de lenguaje. El equipo debe seguir encendido y sin suspensión. La revisión posterior sí requiere interpretar los resultados.
