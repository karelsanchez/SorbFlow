"""Fixed-design E03 numerical amendment; never selects designs on evaluation."""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[name]='1'
import sys,time,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import run_e03 as M

OLD=M.ROOT/'outputs/PyFAST_E03_BENCHMARK_20261120'
PROTOCOL=M.OUT/'protocol/REFINEMENT.json'

def provenance():
    files=[OLD/'protocol/PROTOCOL.json',OLD/'protocol/DESIGN_FREEZE.json',
           OLD/'scenarios/independent_evaluation.json',OLD/'RESULTS.json']
    files+=list((M.OUT/'code').glob('*.py'))
    files+=list((M.ROOT/'PyFAST/src/pyfast').rglob('*.py'))
    return {str(p.relative_to(M.ROOT)):M.digest(p.read_bytes()) for p in sorted(files)}

def freeze():
    if PROTOCOL.exists():raise RuntimeError('Protocol immutable')
    M.write(PROTOCOL,{'study':'E03 fixed-design numerical refinement amendment',
       'prior_knowledge':'Original N40/80 failed 12 sampled curve checks; one feasibility classification changed. All selected designs and 40 evaluation scenarios remain unchanged; no reselection or new optimization.',
       'sources':provenance(),'pairs':[[80,160],[160,320],[320,640]],
       'rule':'All 200 design/scenario pairs begin at 80/160. Stop per pair only if max sampled C/C0 change <=.005 and joint final-concentration/pressure violation classification agrees. Otherwise advance to next declared pair. Unresolved at 640 stays unresolved.',
       'threshold':.005,'criteria_unchanged':True,'new_solve_cap':600,'new_wall_cap_s':3600,
       'historical_cost_separate':881,'workers':1,
       'claims':'Sampled refinement agreement is not a continuous error bound; 40 synthetic scenarios do not certify industrial reliability. No new laboratory data required for software publication.'})
    PROTOCOL.with_suffix('.sha256').write_text(M.digest(PROTOCOL.read_bytes())+'\n')

class Runner(M.Runner):
    def __init__(self):
        import numpy as np
        self.np=np;self.p=M.read(OLD/'protocol/PROTOCOL.json');self.cache_hits=0;self.historical_hits=0
        for path,h in self.p['sources'].items():
            if M.digest((M.ROOT/path).read_bytes())!=h:raise RuntimeError('Historical source changed')
        p=M.read(PROTOCOL)
        if p['sources']!=provenance() or M.digest(PROTOCOL.read_bytes())!=PROTOCOL.with_suffix('.sha256').read_text().strip():raise RuntimeError('Refinement sources changed')
        start=M.OUT/'runs/start.json'
        if not start.exists():M.write(start,{'epoch':time.time()})
        self.epoch=M.read(start)['epoch']
        M.MAX_SOLVES=600;M.MAX_WALL_S=3600

    def solve(self,x,s,cells,phase):
        req={'x':list(map(float,x)),'scenario':list(map(float,s)),'cells':cells,
             'sources':M.key(self.p['sources']),'physics':self.p['physics'],'numerics':self.p['numerics']}
        old=OLD/'runs/cache'/f'{M.key(req)}.json'
        if old.exists():
            if M.digest(old.read_bytes())!=old.with_suffix('.sha256').read_text().strip():raise RuntimeError('Historical cache hash mismatch')
            obj=M.read(old)
            if obj['request']!=req or len(obj['cstar'])!=201 or not all(math.isfinite(v) for v in obj['cstar']):raise RuntimeError('Historical cache content mismatch')
            self.historical_hits+=1;return obj
        return super().solve(x,s,cells,phase)

def run():
    runner=Runner();M.write(M.OUT/'PROCESS.json',{'pid':os.getpid()})
    designs=M.read(OLD/'protocol/DESIGN_FREEZE.json')['selected_designs']
    scenarios=M.read(OLD/'scenarios/independent_evaluation.json')['K_k_Q_multipliers']
    outcomes={}
    for name,x in designs.items():
        rows=[]
        for i,s in enumerate(scenarios):
            history=[]
            for lo,hi in [(80,160),(160,320),(320,640)]:
                a=runner.solve(x,s,lo,'REFINEMENT');b=runner.solve(x,s,hi,'REFINEMENT')
                error=M.compare_curve(a['cstar'],b['cstar'])
                av=a['cstar'][-1]>M.LIMIT or a['pressure_pa']>M.PRESSURE_LIMIT
                bv=b['cstar'][-1]>M.LIMIT or b['pressure_pa']>M.PRESSURE_LIMIT
                ok=error<=.005 and av==bv
                history.append({'coarse_cells':lo,'fine_cells':hi,'curve_difference':error,
                    'violates_coarse':av,'violates_fine':bv,'pass':ok,
                    'mass_scaled_fine':b['diagnostics']['max_scaled_mass_residual']})
                if ok:break
            rows.append({'scenario':i,'resolved':ok,'violates_finest':bv,'history':history})
            M.write(M.OUT/'runs'/f'{name}.json',rows)
            M.write(M.OUT/'STATUS.json',{'status':'RUNNING','design':name,'scenario':i+1,'budget':M.summary_budget()})
        bad=sum(not r['resolved'] for r in rows);k=sum(r['violates_finest'] for r in rows)
        outcomes[name]={'count':40,'unresolved':bad,'violation_count_finest':k,
            'violation_fraction_finest':k/40,'wilson_95_descriptive':M.wilson(k,40),'rows':rows}
        print(name,'unresolved',bad,'violations',k,flush=True)
    if provenance()!=M.read(PROTOCOL)['sources']:raise RuntimeError('Source changed during run')
    status='PASSED_SCOPED_FIXED_DESIGN_REFINEMENT' if all(v['unresolved']==0 for v in outcomes.values()) else 'INCONCLUSIVE_FIXED_DESIGN_REFINEMENT'
    result={'status':status,'designs':outcomes,'new_budget':M.summary_budget(),'historical_solves':881,
            'historical_cache_hits':runner.historical_hits,'current_cache_hits':runner.cache_hits,
            'selection_and_scenarios_unchanged':True,'sources_unchanged':True}
    M.write(M.OUT/'RESULTS.json',result)
    lines=['# E03: refinamiento numérico de diseños congelados','',f'Estado: {status}.','',
        'Se conservaron los cinco diseños y los 40 escenarios anteriores. No se reoptimizó ni se seleccionaron nuevos diseños usando evaluación.', '',
        '| Diseño | No resueltos / 40 | Violaciones en malla final / 40 |','|---|---:|---:|']
    lines += [f"| {n} | {v['unresolved']} | {v['violation_count_finest']} |" for n,v in outcomes.items()]
    lines += ['',f"Solves nuevos: {result['new_budget']['attempted_solves']}; históricos separados: 881.", '',
        'La prueba exige acuerdo entre mallas y estabilidad de la clasificación. No es una cota del error continuo. Las proporciones son descriptivas bajo incertidumbre sintética, sin demostrar superioridad, convergencia de Pareto ni confiabilidad industrial.',
        'La selección previa de candidatos continúa condicionada al presupuesto y malla de entrenamiento originales. Este refinamiento solo resuelve su evaluación numérica. No se requieren nuevos ensayos de laboratorio para publicar el software con este alcance.']
    (M.OUT/'INFORME.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    M.write(M.OUT/'STATUS.json',{'status':status,'budget':M.summary_budget(),'report':'INFORME.md'})

if __name__=='__main__':
    try:
        {'freeze':freeze,'run':run}[sys.argv[1]]()
    except Exception as exc:
        M.write(M.OUT/'STATUS.json',{'status':'STOPPED','error':f'{type(exc).__name__}: {exc}','budget':M.summary_budget()})
        raise
